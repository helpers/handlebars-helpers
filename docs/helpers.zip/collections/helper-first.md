#### \{{first}}
_Returns the first item in a collection._
<br>Parameters: `none`

Data:

```json
"collection": [
  "Amy Wong",
  "Bender",
  "Dr. Zoidberg",
  "Fry",
  "Hermes Conrad",
  "Leela",
  "Professor Farnsworth",
  "Scruffy"
]
```

Template:

```html
\{{first collection}}
```

Renders to:

```html
Amy Wong
```