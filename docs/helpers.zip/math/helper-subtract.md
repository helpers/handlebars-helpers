#### \{{subtract}}
_Returns the difference of two numbers. Opposite of `add`_
<br>Parameters: value `int` - The number to subtract from the expression. (Required)_

Data:

```javascript
value = 5
```
Template:

```html
\{{subtract value 5}}
```
Renders to:

```
0
```
