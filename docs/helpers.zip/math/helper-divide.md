#### \{{divide}}
_Returns the division of two numbers._
<br>Parameters: value `int` - The number to divide the expression. (Required)

Data:

```javascript
value = 5
```
Template:

```html
\{{divide value 5}}
```
Renders to:

```
1
```
