#### \{{add}}
_Returns the sum of two numbers._
<br>Parameters: value `int` - The number to add to the expression. (Required)

Data:

```javascript
value = 5
```
Template:

```html
\{{add value 5}}
```
Renders to:

```
10
```
