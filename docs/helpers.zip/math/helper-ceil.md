#### \{{ceil}}
_Returns the value rounded up to the nearest integer._
<br>Parameters: `none`

Data:

```javascript
value = 5.6
```
Template:

```html
\{{ceil value}}
```
Renders to:

```
6
```
