#### \{{round}}
_Returns the value rounded to the nearest integer._
<br>Parameters: `none`

Data:

```javascript
value = 5.69
```
Template:

```html
\{{round value}}
```
Renders to:

```
6
```
