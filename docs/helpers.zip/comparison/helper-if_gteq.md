#### \{{if_gteq}}
_Conditionally render a block if the value is greater or equal than a given number (If x >= y)._
Parameters: `none`

```html
\{{#if_gteq x compare=y}} ... \{{/if_gteq}}
```

Author: Dan Harper <http://github.com/danharper>