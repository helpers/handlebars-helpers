#### \{{unless_lt}}
_Render block, unless value is less than a given number (Unless x < y)_.

Parameters: `none`

```html
\{{#unless_lt x compare=y}} ... \{{/unless_lt}}
```
Author: Dan Harper <http://github.com/danharper>