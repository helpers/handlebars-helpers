#### \{{if_gt}}
_Conditionally render a block if the value is greater than a given number (If x > y)._
Parameters: `none`

```html
\{{#if_gt x compare=y}} ... \{{/if_gt}}
```

Author: Dan Harper <http://github.com/danharper>