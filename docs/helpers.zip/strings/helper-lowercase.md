#### \{{lowercase}}
_Turns a string to lowercase._
<br>Parameters: `none`

```html
\{{lowercase "MAKE THIS ALL LOWERCASE"}}
```
Renders to:
```
make this all lowercase
```