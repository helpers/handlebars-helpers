#### \{{center}}
_Centers a string using non-breaking spaces._
<br>Parameters: spaces: `int` - The number of spaces. (Required)

```html
\{{center "Bender should not be allowed on tv." 10}}
```
Renders to:

```
|              Bender should not be allowed on tv.              |
```
