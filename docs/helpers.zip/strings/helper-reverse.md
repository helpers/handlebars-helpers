#### \{{reverse}}
_Reverses a string._
<br>Parameters: `none`

```html
\{{reverse "bender should NOT be allowed on TV."}}
```
Renders to:

```
.VT no dewolla eb TON dluohs redneb
```
