#### \{{capitalizeEach}}
_Capitalizes each word in a string._
<br>Parameters: `none`

```html
\{{capitalizeEach "capitalize EACH word in this sentence"}}
```
Renders to:

```
Capitalize EACH Word In This Sentence
```