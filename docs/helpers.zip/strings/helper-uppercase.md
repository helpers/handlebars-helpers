#### \{{uppercase}}
_Turns a string to uppercase. Opposite of `\{{lowercase}}`._
<br>Parameters: `none`

```html
 \{{uppercase "make this all uppercase"}}
```
Renders to:

```
MAKE THIS ALL UPPERCASE
```