#### \{{_dirname}}
_Return the directory name of a path. Similar to the Unix dirname command._

Template:

```html
\{{_dirname '/foo/bar/baz/asdf/quux'}}
```

Renders to:

```
'/foo/bar/baz/asdf'
```
