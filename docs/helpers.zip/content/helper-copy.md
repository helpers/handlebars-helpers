#### \{{copy}}
**example helpers, not for actual use!**
Why do this? The goal is to inspire other concepts that build from this one.

_Example helper, copies file A to path B._
<br>Parameters: `String`
<br> Default: `undefined`

Example:

```html
\{{copy 'a.html' '../dir/b.txt'}}
```

