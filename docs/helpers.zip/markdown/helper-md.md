#### \{{md}}
_Include markdown from specified file(s), and render it to HTML_

Template:

```html
\{{md "file/to/include/post.md"}}
```
Any content inside the "included" markdown file will be rendered as HTML.
