#### \{{log}}
_Simple `console.log()`_

Parameters: `none`

Template

```html
\{{log "Hi console :)"}}
```

Renders to:

```bash
Hi console :)
```
